import { Component } from "@angular/core";

@Component({
    selector: "second",
    template: `<div class="bg-info p-a-1">Drugi komponent.</div>`
})
export class SecondComponent { }
