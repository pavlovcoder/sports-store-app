import { Component } from "@angular/core";

@Component({
    selector: "ondemand",
    moduleId: module.id,
    templateUrl: "ondemand.component.html"
})
export class OndemandComponent { }
