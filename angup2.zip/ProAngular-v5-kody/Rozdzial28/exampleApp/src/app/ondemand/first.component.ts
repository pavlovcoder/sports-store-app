import { Component } from "@angular/core";

@Component({
    selector: "first",
    template: `<div class="bg-primary p-a-1">Pierwszy komponent.</div>`
})
export class FirstComponent { }
