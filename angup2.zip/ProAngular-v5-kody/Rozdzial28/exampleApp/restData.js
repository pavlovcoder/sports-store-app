module.exports = function () {
    var data = {
        products: [
            { id: 1, name: "Kajak", category: "Sporty wodne", price: 275 },
            { id: 2, name: "Kamizelka razunkowa", category: "Sporty wodne", price: 48.95 },
            { id: 3, name: "Piłka nożna", category: "Piłka", price: 19.50 },
            { id: 4, name: "Flagi narożne", category: "Piłka", price: 34.95 },
            { id: 5, name: "Stadium", category: "Piłka", price: 79500 },
            { id: 6, name: "Czapka", category: "Szachy", price: 16 },
            { id: 7, name: "Unsteady Chair", category: "Szachy", price: 29.95 },
            { id: 8, name: "Human Szachy Board", category: "Szachy", price: 75 },
            { id: 9, name: "Bling Bling King", category: "Szachy", price: 1200 }
        ]
    }
    return data
}
